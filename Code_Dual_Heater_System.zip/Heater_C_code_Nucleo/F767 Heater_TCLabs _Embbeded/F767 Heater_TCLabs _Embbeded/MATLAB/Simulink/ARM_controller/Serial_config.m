      %%Define computer-specific variables
      ARM_port ='COM8';