%% Close serial
%% Close port
    clear s;